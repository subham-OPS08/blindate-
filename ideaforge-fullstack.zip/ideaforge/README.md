# IdeaForge v2 — Startup Idea Validator Dashboard

A production-ready full-stack web application with JWT authentication, per-user bookmarks, and a structured category system.

---

## 🚀 Quick Start

### 1. Prerequisites
- Node.js v18+
- MongoDB (local or [MongoDB Atlas](https://cloud.mongodb.com))

### 2. Backend Setup
```bash
cd backend
cp .env.example .env         # Edit MONGO_URI and JWT_SECRET
npm install
npm run seed                  # Seeds categories + demo data
npm run dev                   # Starts server on http://localhost:5000
```

### 3. Frontend
Open `frontend/index.html` directly in your browser.

> The frontend calls `http://localhost:5000/api` — make sure the backend is running first.

### 4. Demo Account
```
Email:    demo@ideaforge.dev
Password: demo1234
```

---

## ⚙️ Tech Stack

| Layer      | Technology                          |
|------------|-------------------------------------|
| Backend    | Node.js + Express.js                |
| Database   | MongoDB + Mongoose                  |
| Auth       | JWT (jsonwebtoken) + bcryptjs       |
| Validation | express-validator                   |
| Frontend   | Vanilla JS SPA (single HTML file)   |
| Fonts      | JetBrains Mono + Syne (Google Fonts)|

---

## 📁 Project Structure

```
ideaforge/
├── backend/
│   ├── config/
│   │   └── db.js                # MongoDB connection
│   ├── middleware/
│   │   └── auth.js              # JWT protect / optionalAuth / requireAdmin
│   ├── models/
│   │   ├── User.js              # name, email, password (hashed), role
│   │   ├── Idea.js              # title, desc, problem, category, difficulty, market, stars
│   │   ├── Bookmark.js          # user + idea (unique index)
│   │   └── Category.js          # name, slug, color, icon, order
│   ├── routes/
│   │   ├── auth.js              # register, login, /me, change-password
│   │   ├── ideas.js             # CRUD + star toggle
│   │   ├── bookmarks.js         # toggle, list, remove
│   │   └── categories.js        # list, get by slug
│   ├── utils/
│   │   └── seed.js              # Category + demo idea seeder
│   ├── .env.example
│   ├── package.json
│   └── server.js
└── frontend/
    └── index.html               # Complete SPA (auth + dashboard + all features)
```

---

## 📡 API Reference

### Auth
| Method | Endpoint                  | Auth | Body / Params              | Description             |
|--------|---------------------------|------|----------------------------|-------------------------|
| POST   | /api/auth/register        | —    | name, email, password      | Create account          |
| POST   | /api/auth/login           | —    | email, password            | Sign in → JWT token     |
| GET    | /api/auth/me              | ✓    | —                          | Get current user        |
| PATCH  | /api/auth/profile         | ✓    | name                       | Update profile          |
| POST   | /api/auth/change-password | ✓    | currentPassword, newPassword | Change password       |

### Categories
| Method | Endpoint           | Auth  | Description         |
|--------|--------------------|-------|---------------------|
| GET    | /api/categories    | —     | List all categories |
| GET    | /api/categories/:slug | —  | Get category by slug|

### Ideas
| Method | Endpoint              | Auth     | Query Params                     | Description          |
|--------|-----------------------|----------|----------------------------------|----------------------|
| GET    | /api/ideas            | optional | category, difficulty, market, search, sort, page, limit | List + filter ideas |
| GET    | /api/ideas/:id        | optional | —                                | Get single idea      |
| POST   | /api/ideas            | ✓        | title, description, problemStatement, category, difficulty, marketPotential | Create idea |
| POST   | /api/ideas/:id/star   | ✓        | —                                | Toggle star          |
| DELETE | /api/ideas/:id        | ✓        | —                                | Delete own idea      |

### Bookmarks
| Method | Endpoint               | Auth | Description                          |
|--------|------------------------|------|--------------------------------------|
| GET    | /api/bookmarks         | ✓    | Get all bookmarked ideas (populated) |
| GET    | /api/bookmarks/ids     | ✓    | Get array of bookmarked idea IDs     |
| POST   | /api/bookmarks/:ideaId | ✓    | Toggle bookmark (add/remove)         |
| DELETE | /api/bookmarks/:ideaId | ✓    | Explicitly remove bookmark           |

---

## ✅ Feature Checklist

### Core Requirements
- [x] Idea Submission (title, description, problem, category, difficulty, market)
- [x] Difficulty Score 1–5 (slider with live label)
- [x] Market Potential (Low / Medium / High / Very High)
- [x] Card Dashboard (animated glassmorphism cards)
- [x] Filtering by category, difficulty (slider), market potential
- [x] Debounced keyword search with result highlighting
- [x] Statistics Panel (total ideas, top category, avg difficulty, charts)
- [x] Input Validation — empty fields + duplicate title (frontend + backend)

### Auth & Users
- [x] JWT Authentication — register + login with bcryptjs password hashing
- [x] Protected routes middleware (`protect`, `optionalAuth`, `requireAdmin`)
- [x] Session persistence via localStorage token
- [x] Token refresh on page load via `/api/auth/me`
- [x] Animated login/signup UI with password strength indicator
- [x] Logout button in sidebar

### Bookmarks
- [x] Toggle bookmark per idea (authenticated users only)
- [x] Animated bookmark icon on every card
- [x] Dedicated "Saved Ideas" page
- [x] Backend storage (Bookmark model, unique constraint)
- [x] APIs: GET /bookmarks, POST /bookmarks/:id, DELETE /bookmarks/:id

### Categories (Structured System)
- [x] Category model stored in MongoDB
- [x] Seed script for predefined categories
- [x] Dynamic filter chips generated from backend data
- [x] Form select dynamically populated from API
- [x] Category idea count tracking

### Bonus Features
- [x] Star / Upvote system (per-user, stored in DB)
- [x] Trending Ideas section (popularity score formula)
- [x] Animated card transitions (staggered entry, 3D mouse-track glow)
- [x] Popularity Score = stars×10 + market_score + difficulty_bonus
- [x] AI Simulation modal with typewriter terminal output
- [x] Analytics panel with animated bar charts
- [x] Responsive mobile-first layout with collapsible sidebar

---

## 🔐 Security Notes

- Passwords are hashed with bcrypt (cost factor 12)
- JWT tokens expire after 7 days (configurable via `JWT_EXPIRE`)
- `protect` middleware validates token on every protected route
- Duplicate title check is case-insensitive
- Input validation on all POST routes (express-validator)
- Users can only delete their own ideas (unless admin)

---

## 🌱 Environment Variables

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/ideaforge
JWT_SECRET=change_this_to_a_long_random_string
JWT_EXPIRE=7d
CLIENT_URL=http://localhost:3000
NODE_ENV=development
```

---

## 📝 License

MIT — free to use, modify, and distribute.
