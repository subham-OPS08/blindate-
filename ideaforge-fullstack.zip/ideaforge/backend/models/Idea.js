const mongoose = require('mongoose');

const ideaSchema = new mongoose.Schema(
  {
    title: {
      type: String, required: [true, 'Title is required'],
      trim: true, minlength: 2, maxlength: 80,
    },
    description: {
      type: String, required: [true, 'Description is required'],
      trim: true, minlength: 10, maxlength: 500,
    },
    problemStatement: {
      type: String, required: [true, 'Problem statement is required'],
      trim: true, minlength: 10, maxlength: 1000,
    },
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category', required: [true, 'Category is required'],
    },
    difficulty: {
      type: Number, required: true, min: 1, max: 5,
    },
    marketPotential: {
      type: String, required: true,
      enum: ['Low', 'Medium', 'High', 'Very High'],
    },
    submittedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', required: true,
    },
    stars: { type: Number, default: 0 },
    starredBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    bookmarkCount: { type: Number, default: 0 },
    views: { type: Number, default: 0 },
    tags: [{ type: String, trim: true }],
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Computed slug
ideaSchema.virtual('slug').get(function () {
  return this.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 40);
});

// Compound text index for search
ideaSchema.index({ title: 'text', description: 'text', problemStatement: 'text' });
// Filter index
ideaSchema.index({ category: 1, difficulty: 1, marketPotential: 1, createdAt: -1 });

module.exports = mongoose.model('Idea', ideaSchema);
