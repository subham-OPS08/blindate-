const mongoose = require('mongoose');

const bookmarkSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User', required: true,
    },
    idea: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Idea', required: true,
    },
  },
  { timestamps: true }
);

// One bookmark per (user, idea) pair
bookmarkSchema.index({ user: 1, idea: 1 }, { unique: true });
// Fast lookup of all bookmarks for a user
bookmarkSchema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model('Bookmark', bookmarkSchema);
