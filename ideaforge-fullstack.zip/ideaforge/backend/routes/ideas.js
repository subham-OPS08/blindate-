const router   = require('express').Router();
const { body, query, validationResult } = require('express-validator');
const Idea     = require('../models/Idea');
const Category = require('../models/Category');
const Bookmark = require('../models/Bookmark');
const User     = require('../models/User');
const { protect, optionalAuth } = require('../middleware/auth');

// ── Score helper ──────────────────────────────
const MKT_SCORE = { Low: 8, Medium: 16, High: 24, 'Very High': 32 };
const calcScore = (idea) =>
  idea.stars * 10 + (MKT_SCORE[idea.marketPotential] || 16) + (6 - idea.difficulty) * 5;

// ── GET /api/ideas ────────────────────────────
router.get('/', optionalAuth, async (req, res) => {
  const { category, difficulty, market, search, sort = '-createdAt', page = 1, limit = 100 } = req.query;

  const filter = {};

  if (category && category !== 'All') {
    const cat = await Category.findOne({ name: category });
    if (cat) filter.category = cat._id;
    else return res.json([]);
  }

  if (difficulty && difficulty !== '5') filter.difficulty = { $lte: parseInt(difficulty) };
  if (market && market !== 'All') filter.marketPotential = market;
  if (search && search.trim()) filter.$text = { $search: search.trim() };

  const skip = (parseInt(page) - 1) * parseInt(limit);

  const ideas = await Idea.find(filter)
    .populate('category', 'name color icon slug')
    .populate('submittedBy', 'name')
    .sort(sort)
    .skip(skip)
    .limit(parseInt(limit))
    .lean({ virtuals: true });

  // Attach bookmark status for authenticated users
  let bookmarkedSet = new Set();
  let starredSet    = new Set();

  if (req.user) {
    const bks = await Bookmark.find({ user: req.user._id }).select('idea').lean();
    bookmarkedSet = new Set(bks.map(b => b.idea.toString()));
    const user = await User.findById(req.user._id).lean();
    // Fetch starred ideas for this user
    const starred = await Idea.find({ starredBy: req.user._id }).select('_id').lean();
    starredSet = new Set(starred.map(i => i._id.toString()));
  }

  const result = ideas.map(idea => ({
    ...idea,
    bookmarked: bookmarkedSet.has(idea._id.toString()),
    starred:    starredSet.has(idea._id.toString()),
    score:      calcScore(idea),
  }));

  res.json(result);
});

// ── GET /api/ideas/:id ────────────────────────
router.get('/:id', optionalAuth, async (req, res) => {
  const idea = await Idea.findById(req.params.id)
    .populate('category', 'name color icon slug')
    .populate('submittedBy', 'name')
    .lean({ virtuals: true });

  if (!idea) return res.status(404).json({ message: 'Idea not found' });

  // Increment views
  await Idea.findByIdAndUpdate(req.params.id, { $inc: { views: 1 } });

  let bookmarked = false, starred = false;
  if (req.user) {
    bookmarked = !!(await Bookmark.findOne({ user: req.user._id, idea: idea._id }));
    starred    = idea.starredBy?.some(id => id.toString() === req.user._id.toString());
  }

  res.json({ ...idea, bookmarked, starred, score: calcScore(idea) });
});

// ── POST /api/ideas ───────────────────────────
router.post('/', protect, [
  body('title').trim().isLength({ min: 2, max: 80 }).withMessage('Title must be 2–80 characters'),
  body('description').trim().isLength({ min: 10, max: 500 }).withMessage('Description: 10–500 characters required'),
  body('problemStatement').trim().isLength({ min: 10, max: 1000 }).withMessage('Problem statement: 10–1000 characters required'),
  body('category').notEmpty().withMessage('Category is required'),
  body('difficulty').isInt({ min: 1, max: 5 }).withMessage('Difficulty must be 1–5'),
  body('marketPotential').isIn(['Low', 'Medium', 'High', 'Very High']).withMessage('Invalid market potential'),
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ message: errors.array()[0].msg, errors: errors.array() });

  const { title, description, problemStatement, category, difficulty, marketPotential } = req.body;

  // Duplicate title check (case-insensitive)
  const dup = await Idea.findOne({ title: { $regex: new RegExp(`^${title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') } });
  if (dup) return res.status(400).json({ message: 'An idea with this title already exists' });

  // Resolve category
  const cat = await Category.findOne({ name: category });
  if (!cat) return res.status(400).json({ message: `Category "${category}" not found` });

  const idea = await Idea.create({
    title, description, problemStatement,
    category: cat._id, difficulty, marketPotential,
    submittedBy: req.user._id,
  });

  // Increment counts
  await Category.findByIdAndUpdate(cat._id, { $inc: { ideaCount: 1 } });
  await User.findByIdAndUpdate(req.user._id, { $inc: { ideaCount: 1 } });

  const populated = await idea.populate([
    { path: 'category', select: 'name color icon slug' },
    { path: 'submittedBy', select: 'name' },
  ]);

  res.status(201).json({ ...populated.toObject({ virtuals: true }), score: calcScore(populated), bookmarked: false, starred: false });
});

// ── POST /api/ideas/:id/star ──────────────────
router.post('/:id/star', protect, async (req, res) => {
  const idea = await Idea.findById(req.params.id);
  if (!idea) return res.status(404).json({ message: 'Idea not found' });

  const uid = req.user._id;
  const idx = idea.starredBy.findIndex(id => id.equals(uid));

  if (idx === -1) {
    idea.starredBy.push(uid);
    idea.stars = Math.max(0, idea.stars + 1);
  } else {
    idea.starredBy.splice(idx, 1);
    idea.stars = Math.max(0, idea.stars - 1);
  }

  await idea.save();
  const starred = idx === -1;
  res.json({ stars: idea.stars, starred, score: calcScore(idea) });
});

// ── DELETE /api/ideas/:id ─────────────────────
router.delete('/:id', protect, async (req, res) => {
  const idea = await Idea.findById(req.params.id);
  if (!idea) return res.status(404).json({ message: 'Idea not found' });
  if (idea.submittedBy.toString() !== req.user._id.toString() && req.user.role !== 'admin')
    return res.status(403).json({ message: 'Not authorized to delete this idea' });

  await Promise.all([
    idea.deleteOne(),
    Bookmark.deleteMany({ idea: idea._id }),
    Category.findByIdAndUpdate(idea.category, { $inc: { ideaCount: -1 } }),
    User.findByIdAndUpdate(idea.submittedBy, { $inc: { ideaCount: -1 } }),
  ]);

  res.json({ message: 'Idea deleted successfully' });
});

module.exports = router;
