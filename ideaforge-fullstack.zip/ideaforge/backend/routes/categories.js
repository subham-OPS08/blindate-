const router   = require('express').Router();
const Category = require('../models/Category');
const { requireAdmin } = require('../middleware/auth');

// GET /api/categories
router.get('/', async (_req, res) => {
  const cats = await Category.find().sort('order name').lean();
  res.json(cats);
});

// GET /api/categories/:slug
router.get('/:slug', async (req, res) => {
  const cat = await Category.findOne({ slug: req.params.slug }).lean();
  if (!cat) return res.status(404).json({ message: 'Category not found' });
  res.json(cat);
});

// POST /api/categories  (admin only)
router.post('/', requireAdmin, async (req, res) => {
  const { name, description, color, icon, order } = req.body;
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  const cat = await Category.create({ name, slug, description, color, icon, order });
  res.status(201).json(cat);
});

module.exports = router;
