const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const jwt  = require('jsonwebtoken');
const User = require('../models/User');
const { protect } = require('../middleware/auth');

// ── Helpers ───────────────────────────────────
const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '7d',
  });

const sendToken = (res, statusCode, user) =>
  res.status(statusCode).json({ token: signToken(user._id), user });

const validationErrors = (req, res) => {
  const errs = validationResult(req);
  if (!errs.isEmpty()) {
    res.status(400).json({ message: errs.array()[0].msg, errors: errs.array() });
    return true;
  }
  return false;
};

// ── POST /api/auth/register ───────────────────
router.post(
  '/register',
  [
    body('name').trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2–50 characters'),
    body('email').isEmail().normalizeEmail().withMessage('Please provide a valid email'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  ],
  async (req, res) => {
    if (validationErrors(req, res)) return;
    const { name, email, password } = req.body;

    if (await User.findOne({ email }))
      return res.status(400).json({ message: 'Email is already registered' });

    const user = await User.create({ name, email, password });
    sendToken(res, 201, user);
  }
);

// ── POST /api/auth/login ──────────────────────
router.post(
  '/login',
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('password').notEmpty().withMessage('Password is required'),
  ],
  async (req, res) => {
    if (validationErrors(req, res)) return;
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user || !(await user.comparePassword(password)))
      return res.status(401).json({ message: 'Invalid email or password' });

    sendToken(res, 200, user);
  }
);

// ── GET /api/auth/me ──────────────────────────
router.get('/me', protect, (req, res) =>
  res.json({ user: req.user })
);

// ── PATCH /api/auth/profile ───────────────────
router.patch(
  '/profile',
  protect,
  [body('name').optional().trim().isLength({ min: 2, max: 50 })],
  async (req, res) => {
    if (validationErrors(req, res)) return;
    const { name } = req.body;
    if (name) req.user.name = name;
    await req.user.save();
    res.json({ user: req.user });
  }
);

// ── POST /api/auth/change-password ───────────
router.post(
  '/change-password',
  protect,
  [
    body('currentPassword').notEmpty().withMessage('Current password required'),
    body('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters'),
  ],
  async (req, res) => {
    if (validationErrors(req, res)) return;
    const { currentPassword, newPassword } = req.body;

    const user = await require('../models/User').findById(req.user._id);
    if (!(await user.comparePassword(currentPassword)))
      return res.status(400).json({ message: 'Current password is incorrect' });

    user.password = newPassword;
    await user.save();
    sendToken(res, 200, user);
  }
);

module.exports = router;
