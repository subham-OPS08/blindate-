const router   = require('express').Router();
const Bookmark = require('../models/Bookmark');
const Idea     = require('../models/Idea');
const { protect } = require('../middleware/auth');

const MKT_SCORE = { Low: 8, Medium: 16, High: 24, 'Very High': 32 };
const calcScore = (idea) =>
  idea.stars * 10 + (MKT_SCORE[idea.marketPotential] || 16) + (6 - idea.difficulty) * 5;

// ── GET /api/bookmarks  (current user's saved ideas) ──
router.get('/', protect, async (req, res) => {
  const bookmarks = await Bookmark.find({ user: req.user._id })
    .populate({
      path: 'idea',
      populate: [
        { path: 'category', select: 'name color icon slug' },
        { path: 'submittedBy', select: 'name' },
      ],
    })
    .sort('-createdAt')
    .lean();

  const ideas = bookmarks
    .filter(b => b.idea)           // guard against deleted ideas
    .map(b => ({
      ...b.idea,
      bookmarked: true,
      bookmarkedAt: b.createdAt,
      score: calcScore(b.idea),
    }));

  res.json(ideas);
});

// ── GET /api/bookmarks/ids  (just idea IDs for client state) ──
router.get('/ids', protect, async (req, res) => {
  const bks = await Bookmark.find({ user: req.user._id }).select('idea').lean();
  res.json(bks.map(b => b.idea.toString()));
});

// ── POST /api/bookmarks/:ideaId  (toggle) ─────────────────────
router.post('/:ideaId', protect, async (req, res) => {
  const idea = await Idea.findById(req.params.ideaId);
  if (!idea) return res.status(404).json({ message: 'Idea not found' });

  const existing = await Bookmark.findOne({ user: req.user._id, idea: idea._id });

  if (existing) {
    await existing.deleteOne();
    await Idea.findByIdAndUpdate(idea._id, { $inc: { bookmarkCount: -1 } });
    return res.json({ bookmarked: false });
  }

  await Bookmark.create({ user: req.user._id, idea: idea._id });
  await Idea.findByIdAndUpdate(idea._id, { $inc: { bookmarkCount: 1 } });
  res.json({ bookmarked: true });
});

// ── DELETE /api/bookmarks/:ideaId  (explicit remove) ─────────
router.delete('/:ideaId', protect, async (req, res) => {
  await Bookmark.findOneAndDelete({ user: req.user._id, idea: req.params.ideaId });
  res.json({ bookmarked: false });
});

module.exports = router;
