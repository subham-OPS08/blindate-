/**
 * IdeaForge — Database Seed Script
 * Usage: node utils/seed.js
 * Options: node utils/seed.js --clear  (wipe all data)
 */
require('dotenv').config();
const mongoose  = require('mongoose');
const Category  = require('../models/Category');
const Idea      = require('../models/Idea');
const User      = require('../models/User');
const Bookmark  = require('../models/Bookmark');
const connectDB = require('../config/db');

const CATEGORIES = [
  { name: 'AI Coding',          slug: 'ai-coding',           description: 'AI-powered coding assistants and completions', color: '#79c0ff', icon: '⚡', order: 1 },
  { name: 'Debugging Tools',    slug: 'debugging-tools',     description: 'Tools for finding and fixing bugs faster',      color: '#f78166', icon: '🔍', order: 2 },
  { name: 'Dev Productivity',   slug: 'dev-productivity',    description: 'Boost developer workflow and efficiency',       color: '#3fb950', icon: '◈', order: 3 },
  { name: 'Code Review',        slug: 'code-review',         description: 'Automated and AI-assisted code review tools',   color: '#bc8cff', icon: '◉', order: 4 },
  { name: 'Learning Assistants',slug: 'learning-assistants', description: 'Personalised developer learning platforms',     color: '#e3b341', icon: '▦', order: 5 },
];

const DEMO_IDEAS = [
  { title: 'CodePilot X',     cat: 'AI Coding',           desc: 'Inline AI pair-programmer that learns your entire codebase and suggests contextually-aware completions in real time.',  prob: 'Junior devs spend 40% of their time looking up APIs and syntax instead of building features.', diff: 3, mkt: 'Very High', stars: 12 },
  { title: 'BugSheriff',      cat: 'Debugging Tools',     desc: 'Automated root-cause analysis tool that traces bugs across microservices with a single CLI command.',                   prob: 'Debugging distributed systems can consume entire sprints, even for senior engineers.',           diff: 4, mkt: 'High',      stars: 8  },
  { title: 'SprintFlow AI',   cat: 'Dev Productivity',    desc: 'AI-powered sprint planner that auto-assigns tasks based on developer skill profiles and historical velocity data.',     prob: 'Sprint planning meetings eat 3–5 hours per week and often result in poor task distribution.',   diff: 2, mkt: 'High',      stars: 5  },
  { title: 'ReviewBot Pro',   cat: 'Code Review',         desc: 'LLM-driven code reviewer that enforces style guides, flags security anti-patterns, and suggests refactors pre-merge.',  prob: 'Manual code review is slow, inconsistent, and often the biggest bottleneck in CI/CD pipelines.',diff: 3, mkt: 'Very High', stars: 15 },
  { title: 'LearnPath',       cat: 'Learning Assistants', desc: 'Adaptive learning platform that generates personalised coding challenges targeting your individual weak spots.',        prob: 'Generic tutorials do not address individual knowledge gaps, slowing developer growth.',          diff: 2, mkt: 'High',      stars: 7  },
  { title: 'ContextDB',       cat: 'AI Coding',           desc: 'Semantic search engine for large codebases — ask natural-language questions, receive precise code answers instantly.', prob: 'New engineers spend weeks understanding legacy codebases before they can contribute.',           diff: 4, mkt: 'Medium',    stars: 3  },
];

async function seed() {
  await connectDB();

  const clear = process.argv.includes('--clear');
  if (clear) {
    await Promise.all([
      Category.deleteMany({}),
      Idea.deleteMany({}),
      User.deleteMany({}),
      Bookmark.deleteMany({}),
    ]);
    console.log('✓ All collections cleared');
  }

  // Seed categories
  for (const cat of CATEGORIES) {
    await Category.findOneAndUpdate({ slug: cat.slug }, cat, { upsert: true, new: true });
  }
  console.log(`✓ ${CATEGORIES.length} categories seeded`);

  // Create demo user
  let demoUser = await User.findOne({ email: 'demo@ideaforge.dev' });
  if (!demoUser) {
    demoUser = await User.create({ name: 'Demo User', email: 'demo@ideaforge.dev', password: 'demo1234' });
    console.log('✓ Demo user created: demo@ideaforge.dev / demo1234');
  }

  // Seed ideas
  for (const d of DEMO_IDEAS) {
    const existing = await Idea.findOne({ title: d.title });
    if (existing) continue;
    const cat = await Category.findOne({ name: d.cat });
    await Idea.create({
      title: d.title, description: d.desc, problemStatement: d.prob,
      category: cat._id, difficulty: d.diff, marketPotential: d.mkt,
      submittedBy: demoUser._id, stars: d.stars,
    });
  }
  console.log(`✓ ${DEMO_IDEAS.length} demo ideas seeded`);
  console.log('\n  Done! Run: npm run dev\n');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
