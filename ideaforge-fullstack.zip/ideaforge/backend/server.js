require('dotenv').config();
const express  = require('express');
const cors     = require('cors');
const path     = require('path');
const connectDB = require('./config/db');

const app = express();

// ── Connect Database ──────────────────────────
connectDB();

// ── Middleware ────────────────────────────────
app.use(cors({
  origin: process.env.CLIENT_URL || '*',
  credentials: true,
}));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Request Logger (dev) ──────────────────────
if (process.env.NODE_ENV !== 'production') {
  app.use((req, _res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
  });
}

// ── API Routes ────────────────────────────────
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/ideas',      require('./routes/ideas'));
app.use('/api/bookmarks',  require('./routes/bookmarks'));
app.use('/api/categories', require('./routes/categories'));

// ── Health Check ──────────────────────────────
app.get('/api/health', (_req, res) =>
  res.json({ status: 'ok', ts: new Date(), version: '2.0.0' })
);

// ── Serve Frontend in Production ──────────────
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../frontend')));
  app.get('*', (_req, res) =>
    res.sendFile(path.resolve(__dirname, '../frontend', 'index.html'))
  );
}

// ── Global Error Handler ──────────────────────
app.use((err, _req, res, _next) => {
  console.error('Server error:', err.message);
  res.status(err.status || 500).json({
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
  });
});

// ── Start Server ──────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`
  ┌─────────────────────────────────────┐
  │  IdeaForge API v2.0.0               │
  │  Running on  http://localhost:${PORT}  │
  │  Mode: ${(process.env.NODE_ENV || 'development').padEnd(27)}│
  └─────────────────────────────────────┘
  `);
});

module.exports = app;
